# Motion Bed Control — GitHub Pages

This folder is ready to upload directly to a GitHub repository and publish with **GitHub Pages**.

## Bed details

- Device: `S4-Y-192-46380:60`
- Service: `FFE0`
- Characteristic: `FFE1`
- Zero G: `FFFFFFFF05000000091706`
- Flat: `FFFFFFFF050000002A56DF`

## Publish from a browser

1. Create a new GitHub repository, for example `motion-bed-control`.
2. Upload all files from this folder to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch **main** and folder **/(root)**.
6. Save.
7. GitHub will provide an HTTPS Pages address after deployment.

## Use on Windows

Open the GitHub Pages address in Chrome or Edge, press **Connect Bed**, select `S4-Y-192-46380:60`, and use **Zero G** or **Flat**.

## Use on iPhone

Safari does not expose Web Bluetooth. Open the GitHub Pages address in a Web-Bluetooth-capable iOS browser such as Bluefy, then press **Connect Bed**.

## Important browser behavior

The browser must ask you to select/authorize the Bluetooth device. A normal webpage cannot silently take control of a nearby BLE device without that permission.
